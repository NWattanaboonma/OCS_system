package com.example.demo.model;

import edu.gemini.app.ocs.model.AstronomicalData;
import edu.gemini.app.ocs.model.DataProcRequirement;
import edu.gemini.app.ocs.model.StarSystem;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class SciencePlan extends edu.gemini.app.ocs.model.SciencePlan {
    private int planNo;
    private String creator;
    private String submitter;
    private double fundingInUSD;
    private String objectives;
    private StarSystem.CONSTELLATIONS starSystem;
    private Date startDate;
    private Date endDate;
    private TELESCOPELOC telescopeLocation;
    private final ArrayList<ArrayList<DataProcRequirement>> dataProcRequirements = new ArrayList<>();
    private final AstronomicalData astroData = new AstronomicalData();
    private STATUS status;

    SciencePlan(SciencePlanBuilder builder) {
        this.planNo = builder.planNo;
        this.creator = builder.creator;
        this.submitter = builder.submitter;
        this.fundingInUSD = builder.fundingInUSD;
        this.objectives = builder.objectives;
        this.starSystem = builder.starSystem;
        this.startDate = builder.startDate;
        this.endDate = builder.endDate;
        this.telescopeLocation = builder.telescopeLocation;
        this.dataProcRequirements.add(builder.dataProcRequirements);
        this.status = builder.status;
    }

    @Override
    public String getCreator() {
        return this.creator;
    }

    @Override
    public String getSubmitter() {
        return this.submitter;
    }

    @Override
    public String getObjectives() {
        return this.objectives;
    }

    @Override
    public double getFundingInUSD() {
        return this.fundingInUSD;
    }

    @Override
    public STATUS getStatus() {
        return this.status;
    }

    @Override
    public String getStartDate() {
        String sDate = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            sDate = formatter.format(this.startDate);
        } catch (Exception var4) {
            sDate = "-1";
        }
        return sDate;
    }

    @Override
    public String getEndDate() {
        String eDate = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            eDate = formatter.format(this.endDate);
        } catch (Exception var4) {
            eDate = "-1";
        }
        return eDate;
    }

    @Override
    public StarSystem.CONSTELLATIONS getStarSystem() {
        return this.starSystem;
    }

    @Override
    public TELESCOPELOC getTelescopeLocation() {
        return this.telescopeLocation;
    }

    @Override
    public ArrayList<DataProcRequirement> getDataProcRequirements() {
        // Convert your nested ArrayList to the format expected by OCS
        ArrayList<DataProcRequirement> result = new ArrayList<>();
        if (this.dataProcRequirements != null && !this.dataProcRequirements.isEmpty()) {
            for (ArrayList<DataProcRequirement> innerList : this.dataProcRequirements) {
                if (innerList != null) {
                    result.addAll(innerList);
                }
            }
        }
        return result;
    }

    public String getDetail() {
//        if (this.creator != null && this.submitter != null && this.objectives != null && this.starSystem != null && this.startDate != null && this.endDate != null && this.telescopeLocation != null && this.dataProcRequirements != null && this.status != null) {
//            int var10000 = this.planNo;
//            return "{planNo=" + var10000 + ", creator='" + this.creator + "', submitter='" + this.submitter + "', fundingInUSD=" + this.fundingInUSD + ", objectives='" + this.objectives + "', starSystem=" + String.valueOf(this.starSystem) + ", startDate=" + (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).format(this.startDate) + ", endDate=" + (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).format(this.endDate) + ", telescopeLocation='" + String.valueOf(this.telescopeLocation) + "', status='" + String.valueOf(this.status) + "', " + String.valueOf(this.dataProcRequirements) + "}\n";
//        } else {
//            return "ERROR: Cannot print the science plan. Some of the attributes are null.";
//        }
        return "{planNo=" + this.planNo + ", creator='" + this.creator + "', submitter='" + this.submitter + "', fundingInUSD=" + this.fundingInUSD + ", objectives='" + this.objectives + "', starSystem=" + String.valueOf(this.starSystem) + ", startDate=" + (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).format(this.startDate) + ", endDate=" + (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).format(this.endDate) + ", telescopeLocation='" + String.valueOf(this.telescopeLocation) + "', status='" + String.valueOf(this.status) + "', " + String.valueOf(this.dataProcRequirements) + "}";
    }
}