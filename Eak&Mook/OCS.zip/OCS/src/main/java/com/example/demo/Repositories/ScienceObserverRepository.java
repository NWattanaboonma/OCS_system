package com.example.demo.Repositories;

import com.example.demo.user.*;
import org.springframework.data.repository.CrudRepository;

public interface ScienceObserverRepository extends CrudRepository<ScienceObserver, Integer> {
}
