package com.example.demo.controller;

import com.example.demo.Repositories.*;
import com.example.demo.login.*;
import com.example.demo.user.*;
import com.example.demo.enums.*;

import com.example.demo.Repositories.UserRepository;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.servlet.http.HttpSession;



import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class AppController {
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private AstronomerRepository astronomerRepo;
    @Autowired
    private LoginRepository loginRepo;
    @Autowired
    UsernameGeneratorService idGen;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private UserSessionRepository userSessionRepo;

    @CrossOrigin
    @GetMapping("/")
    public String welcome() {
        // show the welcome page at the root
//        return "Hello, welcome to the Heroes application";
            return "login";
    }

    @GetMapping("/users")
    public @ResponseBody Iterable<User> getAllUsers() {
        // show the welcome page at the root
        return userRepo.findAll();
    }

    @GetMapping("/astronomer_home")
    public String astronomerHome(HttpServletResponse response, HttpSession session, Model model) {
        // prevent cache
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");

        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        model.addAttribute("name", user.getFirstname() + " " + user.getLastname());
        model.addAttribute("role", user.getRole().name());
        return "astronomer_home";
    }

    @GetMapping("/observer_home")
    public String observerHome(HttpServletResponse response, HttpSession session, Model model) {
        // prevent cache
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");

        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        model.addAttribute("name", user.getFirstname() + " " + user.getLastname());
        model.addAttribute("role", user.getRole().name());
        return "observer_home";
    }


    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }



    @PostMapping("/login")
    public String loginForm(@RequestParam String username,
                            @RequestParam String password,
                            HttpSession session,
                            Model model) {
        Optional<Login> login = loginRepo.findById(username);
        if (login.isPresent() && login.get().getPassword().equals(password)) {
            User user = login.get().getUser();
            String token = jwtService.generateToken(username);

            UserSession userSession = new UserSession(user, token);
            userSessionRepo.save(userSession); // 🔹 Save to DB
            session.setAttribute("userSession", userSession); // 🔹 Set to session
            session.setAttribute("user", user);

            model.addAttribute("name", user.getFirstname());
            model.addAttribute("role", user.getRole());

            return switch (user.getRole()) {
                case ASTRONOMER -> "redirect:/science-plans";
                case SCIENCE_OBSERVER -> "redirect:/Valid";
                default -> "loginSuccess";
            };
        } else {
            model.addAttribute("error", "<Invalid credentials>");
            return "login";
        }
    }



    @GetMapping("/signup")
    public String signupPage(Model model) {
        model.addAttribute("roles", List.of(Role.ASTRONOMER, Role.SCIENCE_OBSERVER));
        model.addAttribute("accessLevels", AccessLevel.values());  // Add this line
        return "signup";
    }

    @PostMapping("/signup")
    public String handleSignup(@ModelAttribute SignupRequest request, RedirectAttributes redirectAttributes) {
        try {
            User user;
            String username;

            if (request.getRole().equals(Role.ASTRONOMER)) {
                String astroId = idGen.generateAstronomerID();
                user = new Astronomer(
                        request.getFirstname(),
                        request.getLastname(),
                        request.getEmail(),
                        request.getRole(),
                        request.getAccessLevel(),
                        astroId,
                        request.getAffiliation()
                );
                username = astroId;
            } else {
                String observerId = idGen.generateObserverID();
                user = new ScienceObserver(
                        request.getFirstname(),
                        request.getLastname(),
                        request.getEmail(),
                        request.getRole(),
                        request.getAccessLevel(),
                        observerId
                );
                username = observerId;
            }

            userRepo.save(user);
            loginRepo.save(new Login(username, request.getPassword(), user));

            // Pass to login page via Flash attributes
            redirectAttributes.addFlashAttribute("username", username);
            redirectAttributes.addFlashAttribute("password", request.getPassword());

            return "redirect:/login";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error creating account: " + e.getMessage());
            return "redirect:/signup";
        }
    }


    @GetMapping("/logout")
    public String logout(HttpSession session) {
        UserSession userSession = (UserSession) session.getAttribute("userSession");
        if (userSession != null) {
            userSession.setLogoutTime(LocalDateTime.now());
            userSessionRepo.save(userSession); // 🔹 persist updated logout time
        }
        session.invalidate(); // 🔹 destroy session after saving
        return "redirect:/login";
    }

    @PostConstruct
    public void init() {
        // Astronomers
        Astronomer a1 = userRepo.save(new Astronomer("Jane", "Doe", "jane@obs.org", Role.ASTRONOMER, AccessLevel.OBSERVING, idGen.generateAstronomerID(), "ESO"));
        Astronomer a2 = userRepo.save(new Astronomer("John", "Smith", "john@obs.org", Role.ASTRONOMER, AccessLevel.TEST, idGen.generateAstronomerID(), "NASA"));

        // Observers
        ScienceObserver o1 = userRepo.save(new ScienceObserver("Alice", "Wong", "alice@obs.org", Role.SCIENCE_OBSERVER, AccessLevel.OBSERVING, idGen.generateObserverID()));
        ScienceObserver o2 = userRepo.save(new ScienceObserver("Bob", "Lee", "bob@obs.org", Role.SCIENCE_OBSERVER, AccessLevel.MAINTAINANCE, idGen.generateObserverID()));

        // Login
        loginRepo.save(new Login(a1.getAstronomerID(), "password123", a1));
        loginRepo.save(new Login(a2.getAstronomerID(), "password123", a2));
        loginRepo.save(new Login(o1.getObserverID(), "password123", o1));
        loginRepo.save(new Login(o2.getObserverID(), "password123", o2));
    }

}
