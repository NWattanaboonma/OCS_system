package com.example.demo.user;

import com.example.demo.enums.*;
import jakarta.persistence.*;
import java.util.*;

@Entity
@PrimaryKeyJoinColumn(name = "userID") // เชื่อมด้วย userID จาก parent
public class ScienceObserver extends User{
    private String observerID;

//    private List<LogEntry> observingLog;

    public ScienceObserver() {
        super();
    }


    public ScienceObserver(String fname, String lname, String email,
                           Role role, AccessLevel accessLevel, String observerID) {
        super(fname, lname, email, role, accessLevel);
        this.observerID = observerID;
    }

    public String getObserverID() {
        return observerID;
    }

    public String getScienceObserverDetails() {
        return "ScienceObserver details are coming soon!";
    }
}