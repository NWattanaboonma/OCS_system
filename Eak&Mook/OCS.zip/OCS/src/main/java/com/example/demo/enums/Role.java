package com.example.demo.enums;

public enum Role {
    ASTRONOMER,
    SCIENCE_OBSERVER,
    TELESCOPE_OPERATOR,
    SUPPORTER,
    ADMINISTRATOR
}
