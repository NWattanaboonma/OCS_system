package com.example.demo.enums;

public enum AccessLevel {
    OBSERVING,
    MAINTAINANCE,
    TEST
}
