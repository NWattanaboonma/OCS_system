package com.example.demo.controller;

import edu.gemini.app.ocs.OCS;
import edu.gemini.app.ocs.model.DataProcRequirement;
import edu.gemini.app.ocs.model.SciencePlan;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;


@Controller
public class ValidController {

    private static OCS ocs = new OCS(true);

    private OCS sciencePlanService;

    @CrossOrigin
    @GetMapping("/Valid")
    public String validPage(Model model) {
        ArrayList<SciencePlan> allPlans = ocs.getAllSciencePlans();
        ArrayList<SciencePlan> submittedPlans = new ArrayList<>();
        for (SciencePlan plan : allPlans) {
            if ("SUBMITTED".equalsIgnoreCase(String.valueOf(plan.getStatus()))) {
                submittedPlans.add(plan);
            }
        }
        model.addAttribute("sciencePlans", submittedPlans);
        return "Valid";
    }

    @GetMapping("/sciencePlan/valid/{planNumber}")
    public String validSciencePlan(@PathVariable int planNumber, Model model) {
        int index = planNumber - 1;
        SciencePlan plan = ocs.getSciencePlanByNo(planNumber); // OCS method


        model.addAttribute("plan", plan);
        model.addAttribute("index", index);

        return "ValidatePlan";
    }
    @GetMapping("/sciencePlan/more_detail/{planNumber}")
    public String moreDetailSciencePlan(@PathVariable int planNumber, Model model) {
        int index = planNumber - 1;
        SciencePlan plan = ocs.getSciencePlanByNo(planNumber); // OCS method


        model.addAttribute("plan", plan);
        model.addAttribute("index", index);

        return "MoreDetail";
    }
    @PostMapping("/sciencePlan/setStatus/{id}")
    @ResponseBody
    public Map<String, String> setSciencePlanStatus(
            @PathVariable int id,
            @RequestParam String status) {
        ocs.updateSciencePlanStatus(id, SciencePlan.STATUS.valueOf(status));
        Map<String, String> response = new HashMap<>();
        response.put("message", (status.equals("INVALIDATED")
                ? "SciencePlan marked as Invalid: PlanID " + id
                : "Valid date SciencePlan Success: PlanID " + id));
        response.put("redirectUrl", "/Valid");
        return response;
    }



}



