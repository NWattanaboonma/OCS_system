package com.example.demo.user;


import com.example.demo.enums.TelescopeStatus;

import java.util.*;

public class LogEntry {
    private Date timestamp;
    private String actionPerformed;
    private TelescopeStatus telescopeStatus;
    private String datacollected;

    public LogEntry(Date timestamp, String actionPerformed, TelescopeStatus telescopeStatus) {}
}
