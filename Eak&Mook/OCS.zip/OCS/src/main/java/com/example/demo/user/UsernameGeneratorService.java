package com.example.demo.user;


import com.example.demo.Repositories.AstronomerRepository;
import com.example.demo.Repositories.ScienceObserverRepository;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;

@Service
public class UsernameGeneratorService {

    @Autowired
    private AstronomerRepository astronomerRepo;
    @Autowired
    private ScienceObserverRepository observerRepo;

    public String generateAstronomerID() {
        return "A" + String.format("%05d", (int)(Math.random() * 100000));
    }

    public String generateObserverID() {
        return "S" + String.format("%05d", (int)(Math.random() * 100000));
    }
}

