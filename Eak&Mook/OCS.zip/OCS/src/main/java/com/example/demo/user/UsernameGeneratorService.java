package com.example.demo.user;


import com.example.demo.Repositories.AstronomerRepository;
import com.example.demo.Repositories.ScienceObserverRepository;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;

@Service
public class UsernameGeneratorService {

    @Autowired
    private AstronomerRepository astronomerRepo;
    @Autowired
    private ScienceObserverRepository observerRepo;

    public String generateAstronomerID() {
        long count = astronomerRepo.count() + 1;
        return String.format("a%07d", count);
    }

    public String generateObserverID() {
        long count = observerRepo.count() + 1;
        return String.format("s%07d", count);
    }
}

