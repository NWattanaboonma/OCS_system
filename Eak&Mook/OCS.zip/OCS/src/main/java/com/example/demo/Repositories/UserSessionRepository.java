package com.example.demo.Repositories;

import com.example.demo.login.UserSession;
import org.springframework.data.repository.CrudRepository;

public interface UserSessionRepository extends CrudRepository<UserSession, Long> {}