package com.example.demo.user;

import com.example.demo.enums.*;
import jakarta.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name = "userID")
public class Astronomer extends User {
    private String astronomerID;
    private String affiliation;

    public Astronomer() {
        super();
    }

    public Astronomer(String fname, String lname, String email,  Role role, AccessLevel accessLevel, String astronomerID, String affiliation) {
        super(fname, lname, email, role, accessLevel);
        this.astronomerID = astronomerID;
        this.affiliation = affiliation;
    }

    public String getAstronomerID() {
        return astronomerID;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public String getAstronomerDetails() {
        return "Astronomer details are coming soon!";
    }
}