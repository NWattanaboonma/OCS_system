package com.example.demo.login;

import com.example.demo.user.User;
import jakarta.persistence.*;

@Entity
public class Login {
    @Id
    @Column(unique = true)
    private String username; // e.g., a0000001, s0000001

    private String password;

    @OneToOne
    private User user;

    public Login() {}

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Login(String username, String password, User user) {
        this.username = username;
        this.password = password;
        this.user = user;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    public boolean validateCredentials(User user) {
//        return user.getEmail().equals(this.username) &&
//                user.getPassword().equals(this.password); // ต้องเพิ่ม field password ใน User ด้วย
//    }


    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

}
