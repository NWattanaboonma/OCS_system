# SpringBootOCS

This is a demo project of Spring boot using OCS.