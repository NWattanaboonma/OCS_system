package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ValidController {

    @CrossOrigin
    @GetMapping("/Valid")
    public String validPage() {
        return "Valid";
    }

    @GetMapping("/Valid_information")
    public String validInformationPage() {
        return "ValidatePlan";
    }
}
