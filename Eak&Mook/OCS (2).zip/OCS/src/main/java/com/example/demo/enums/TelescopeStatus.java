package com.example.demo.enums;

public enum TelescopeStatus {
}
