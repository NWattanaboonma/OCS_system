package com.example.demo.Repositories;

import com.example.demo.login.Login;

import org.springframework.data.repository.CrudRepository;

public interface LoginRepository extends CrudRepository<Login, String> {
}
