package com.example.demo.Repositories;


import com.example.demo.user.Astronomer;
import org.springframework.data.repository.CrudRepository;

public interface AstronomerRepository extends CrudRepository<Astronomer, Integer> {
}
