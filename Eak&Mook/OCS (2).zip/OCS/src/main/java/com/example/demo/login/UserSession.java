package com.example.demo.login;

import com.example.demo.user.User;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
public class UserSession {
    @Id @GeneratedValue
    private Long id;

    @ManyToOne
    private User user;

    private String token;
    private LocalDateTime loginTime;
    private LocalDateTime logoutTime;

    public UserSession() {}

    public UserSession(User user, String token) {
        this.user = user;
        this.token = token;
        this.loginTime = LocalDateTime.now();
    }

    // Getters
    public User getUser() {
        return user;
    }

    public String getToken() {
        return token;
    }

    public LocalDateTime getLoginTime() {
        return loginTime;
    }

    public LocalDateTime getLogoutTime() {
        return logoutTime;
    }

    // Setters
    public void setUser(User user) {
        this.user = user;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setLoginTime(LocalDateTime loginTime) {
        this.loginTime = loginTime;
    }

    public void setLogoutTime(LocalDateTime logoutTime) {
        this.logoutTime = logoutTime;
    }
}

