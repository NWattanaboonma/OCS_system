package com.example.demo.model;

import edu.gemini.app.ocs.model.DataProcRequirement;
import edu.gemini.app.ocs.model.StarSystem;
import edu.gemini.app.ocs.model.SciencePlan;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class SciencePlanBuilder {

    int planNo;
    String creator;
    String submitter;
    double fundingInUSD;
    String objectives;
    StarSystem.CONSTELLATIONS starSystem;
    Date startDate;
    Date endDate;
    SciencePlan.TELESCOPELOC telescopeLocation;
    ArrayList<DataProcRequirement> dataProcRequirements = new ArrayList<>();
    //    private AstronomicalData astroData = new AstronomicalData();
    SciencePlan.STATUS status;

    public SciencePlanBuilder setCreator(String creator) {
        this.creator = creator;
        return this;
    }

    public SciencePlanBuilder setSubmitter(String submitter) {
        this.submitter = submitter;
        return this;
    }

    public SciencePlanBuilder setFundingInUSD(double funding) {
        this.fundingInUSD = funding;
        return this;
    }

    public SciencePlanBuilder setObjective(String objective) {
        this.objectives = objective;
        return this;
    }

    public SciencePlanBuilder setStarSystem(StarSystem.CONSTELLATIONS target) {
        this.starSystem = target;
        return this;
    }

    public SciencePlanBuilder setStartDate(String startDate) {
        try {
            this.startDate = (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).parse(startDate);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid start date format", e);
        }
        return this;
    }

    public SciencePlanBuilder setEndDate(String endDate) {
        try {
            this.endDate = (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")).parse(endDate);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid end date format", e);
        }
        return this;
    }

    public SciencePlanBuilder setTelescopeLocation(SciencePlan.TELESCOPELOC telescopeLocation) {
        this.telescopeLocation = telescopeLocation;
        return this;
    }

    public SciencePlanBuilder setDataProcessing(ArrayList<DataProcRequirement> dataProcessing) {
        this.dataProcRequirements = dataProcessing;
        return this;
    }

    public SciencePlanBuilder setStatus(SciencePlan.STATUS status) {
        this.status = status;
        return this;
    }

    // --- Build Method ---
//    public SciencePlan build() {
//        this.planNo = generatePlanID();
//        return new SciencePlan();
//    }
    public SciencePlan build() {
        this.planNo = generatePlanID();
        return new SciencePlan(
                // You're missing this field in your builder
                // This might need better formatting
        );
    }


    // --- ID Generator ---
    private int generatePlanID() {
        return (int) (System.currentTimeMillis() % Integer.MAX_VALUE);
    }

    //add data processing
}