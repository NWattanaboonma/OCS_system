package com.example.demo.user;

import com.example.demo.enums.*;
import jakarta.persistence.*;

@Entity
@Table(name = "\"USER\"")
@Inheritance(strategy = InheritanceType.JOINED)
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userID;

    private String firstname;
    private String lastname;
    private String email;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Enumerated(EnumType.STRING)
    private AccessLevel accessLevel;

    public User() {
        // required by JPA
    }

    public User(String fname, String lname, String email,  Role role, AccessLevel accessLevel) {
        this.firstname = fname;
        this.lastname = lname;
        this.email = email;
        this.role = role;
        this.accessLevel = accessLevel;
    }

    public int getUserID() {
        return userID;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getEmail() {
        return email;
    }

    public Role getRole() {
        return role;
    }

    public AccessLevel getAccessLevel() {
        return accessLevel;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setAccessLevel(AccessLevel accessLevel) {
        this.accessLevel = accessLevel;
    }
}
